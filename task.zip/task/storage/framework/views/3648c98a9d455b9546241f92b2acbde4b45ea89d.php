
   
<?php $__env->startSection('content'); ?>
<h1>REST API</h1>
<h3>For API CRUD refer following path:</h3>

<pre>
	<div class="hljs ini">
		routes/api.php
	</div>
</pre>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnt\resources\views/api.blade.php ENDPATH**/ ?>