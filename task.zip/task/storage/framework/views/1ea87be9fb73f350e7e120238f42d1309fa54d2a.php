
 
<?php $__env->startSection('content'); ?>
<h1>Geomatric Shape</h1>
<div class="row">
    <div class="col-6">
    <img src="<?php echo e(route('shape1')); ?>" alt="Shape 1"> 
  </div>
  <div class="col-6">
    <img src="<?php echo e(route('shape2')); ?>" alt="Shape 2">
  </div>
</div>
<div class="row mt-2">
  <div class="col-6">
    <img src="<?php echo e(route('shape3')); ?>" alt="Shape 3">
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnt\resources\views/shapes.blade.php ENDPATH**/ ?>