
   
<?php $__env->startSection('content'); ?>
<h1>Command</h1>
<h3>Run below command for Sample data generate</h3>

<pre>
	<div class="hljs ini">
		Command: php artisan generate:data {NUMBER_OF_RECORD}.
		Command: php artisan create:files {NUMBER_OF_FILES}
	</div>
</pre>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lnt\resources\views/command.blade.php ENDPATH**/ ?>