@extends('layouts.app')
   
@section('content')
<h1>REST API</h1>
<h3>For API CRUD refer following path:</h3>

<pre>
	<div class="hljs ini">
		routes/api.php
	</div>
</pre>
@endsection